# resource.images.moviegenreicons.sutekh
